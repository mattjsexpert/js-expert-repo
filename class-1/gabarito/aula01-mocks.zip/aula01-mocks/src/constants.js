const constants = {
    error: {
        FILE_LENGTH_ERROR_MESSAGE: 'The content length is invalid!',
        FILE_FIELDS_ERROR_MESSAGE: 'The provided properties are invalid!'
    }
}

module.exports = constants